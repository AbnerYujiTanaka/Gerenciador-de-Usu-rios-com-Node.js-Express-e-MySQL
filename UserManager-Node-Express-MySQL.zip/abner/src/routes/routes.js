const express = require('express');
const userController = require('../controllers/userController');
const router = express.Router();

router.get('/login', userController.showLoginPage);
router.get('/register', userController.showRegisterPage);
router.post('/register', userController.registerUser);
router.post('/login', userController.loginUser);
router.get('/logout', userController.logoutUser);

router.get('/users', userController.getAllUsers);
router.get ('/add' , userController.showAddPage);
router.post ('/add' , userController.add);
router.get('/edit/:id', userController.getUserById);
router.post('/edit/:id', userController.updateUser);
router.get('/dell/:id', userController.getdeleteByUser);
router.post('/dell/:id', userController.deleteUser);

module.exports = router;
