/*
  Warnings:

  - Added the required column `endereco` to the `User` table without a default value. This is not possible if the table is not empty.
  - Added the required column `fone` to the `User` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE `user` ADD COLUMN `endereco` VARCHAR(191) NOT NULL,
    ADD COLUMN `fone` VARCHAR(191) NOT NULL;
