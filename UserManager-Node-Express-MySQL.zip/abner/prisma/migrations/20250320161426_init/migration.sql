-- AlterTable
ALTER TABLE `user` MODIFY `fone` VARCHAR(191) NOT NULL;
